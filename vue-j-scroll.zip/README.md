# vue-j-scroll

> A Vue.js project

## 一个循环滚动列表插件

该插件为 vue-seamless-scroll 的升级版 ，可以自动滚动也可以手动滚动。dom 中的事件也保存了下来。
推荐数据量小于 1000，以保证插件的性能。

```bash
npm install @david-j/vue-j-scroll --save-dev 来安装


在项目中使用
import VueScroll from '@david-j/vue-j-scroll';
Vue.use(VueScroll);
```

```bash

示例：

    <vue-j-scroll
      class="list-style"
      :data="youData"
      :steep="1"
      scrollDirection="bottom"
      :isRoller="true"
      :rollerScrollDistance="50"
    >
      <template>
        <li
          v-for="(item, index) in newData"
          :key="'t' + index"
        >
          <p>{{ item + "rrrrssserrdd" }}</p>
        </li>
      </template>
    </vue-j-scroll>

```

steep 滚动的速率；
scrollDirection 滚动的方向（暂支持 top ,bottom）；
isRoller 是否可以使用滚轮滚动；
rollerScrollDistance 滚轮滚动的速率 （isRoller 必须为 true）；
data 接收异步数据（同步任务可不传）；

注：一定要为 vue-j-scroll 组件设置高度
