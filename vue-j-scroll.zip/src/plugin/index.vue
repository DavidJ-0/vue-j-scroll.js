<template>
  <div
    class="custom-list dddd"
    ref="scrollBody"
    @mouseenter="mouseenterFunc"
    @mouseleave="mouseleaveFunc"
    @mousewheel="mousewheelFunc"
  >
    <div
      class="list-body"
      ref="listBody"
      :style="{ transform: getScrollDistance() }"
    >
      <slot></slot>
    </div>
    <div
      class="list-body"
      ref="tBody"
      :style="{ transform: getScrollDistance() }"
    >
      <slot></slot>
    </div>

    <!-- <button @click="stop">stop</button>
    <button @click="start">start</button>
    <button @click="initData">result</button> -->
  </div>
</template>

<script>
export default {
  name: "vue-j-scroll",
  props: {
    steep: {
      //滚动速度
      type: Number,
      default: 1,
    },
    scrollDirection: {
      //滚动方向
      type: String,
      default: "top",
    },
    isRoller: {
      //是否可以滑轮滚动
      type: Boolean,
      default: true,
    },
    rollerScrollDistance: {
      //滑轮滚动的距离
      type: Number,
      default: 20,
    },
    data: Array,
  },
  data() {
    return {
      timer: null, //滚动定时器
      scrollDistance: 0, //滚动距离
      tDom: "", //复制的容器
      bodyHeight: 0, //滚动容器高度
      listHeight: 0, //列表高度
      isStop: !1,
      isStart: !1,
    };
  },
  methods: {
    start() {
      let that = this;
      //滚动函数
      that.isStop = !1;
      window.requestAnimationFrame(this.run);
    },
    run() {
      let that = this;
      let scrollDistance = Math.abs(that.scrollDistance);
      if (that.scrollDistance < 0) {
        let cc = 2 * that.listHeight - that.bodyHeight;
        if (scrollDistance > cc) {
          that.scrollDistance = -(that.listHeight - that.bodyHeight);
        }
      } else {
        that.scrollDistance = -that.listHeight;
      }

      if (!that.isStop) {
        if (that.scrollDirection === "top") {
          that.scrollDistance -= that.steep;
        } else if (that.scrollDirection === "bottom") {
          that.scrollDistance += that.steep;
        }
        window.requestAnimationFrame(that.run);
      }
    },
    stop() {
      this.isStop = !0;
    },
    initData() {
      this.scrollDistance = 0;
    },
    getScrollDistance() {
      let c = "translate(0px, " + this.scrollDistance + "px)";
      return c;
    },

    mouseenterFunc() {
      this.stop();
    },
    mouseleaveFunc() {
      this.start();
    },
    mousewheelFunc(e) {
      if (!this.isRoller) {
        return false;
      }

      // if (this.scrollDirection !== "top" || this.scrollDirection !== "bottom") {
      //   return;
      // }
      let dis = e.deltaY;
      if (dis > 0) {
        this.scrollDistance -= this.rollerScrollDistance;
      } else {
        this.scrollDistance += this.rollerScrollDistance;
      }

      this.run();
    },
  },
  watch: {
    data(newval, oldval) {
      this.$nextTick(() => {
        this.bodyHeight = this.$refs.scrollBody.clientHeight;
        this.listHeight = this.$refs.tBody.clientHeight;
        if (!this.isStart) {
          this.start();
        }
      });
    },
  },

  beforeMount() {},
  mounted() {
    // this.tDom = this.$slots.default;
    // this.$slots.body2 = this.tDom;

    this.$nextTick(() => {
      this.bodyHeight = this.$refs.scrollBody.clientHeight;
      this.listHeight = this.$refs.tBody.clientHeight;
      //默认滚动位置
      this.initData();
      if (this.bodyHeight !== 0 && this.listHeight !== 0) {
        this.start();
        this.isStart = !0;
      }
    });
  },
  // beforeUpdate() {
  //   console.log("bupdate");
  // },
  // updated() {
  //   console.log("update");
  // },
  beforeDestroy() {
    clearInterval(this.timer);
    this.timer = null;
  },
  created() {},
  beforeCreate() {},
};
</script>

<style scoped>
.custom-list {
  /* overflow: hidden; */
}
.list-body {
  overflow: hidden;
}
</style>
